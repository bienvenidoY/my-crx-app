(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/chunk-f45a0fde.js")
    );
  })().catch(console.error);

})();
